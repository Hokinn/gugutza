<?php

    include 'config.php';
    include 'lib/tmdb.php';
    include 'blocks/search.php';

    // include 'blocks/popular.php';
    // include 'blocks/genres.php';
    

?>