<?php

    $genres = get_genres();
    
?>

<div>
    <h2>Genres:</h2>
    <ul>
        <?php foreach($genres['genres'] as $genre) { ?>
        <li>
            <a href=""><?php print $genre['name']; ?></a>
        </li>
        <?php } ?>
    </ul>
</div>