<?php 

    $data = search_movie( $_GET['q']);

?>
<form>
    <input name="q" type="text" placeholder="search here...">
    <button>SEARCH</button>
</form>
<ul>
    <?php foreach($data['results'] as $result) { ?>
        <li>
            <a href=""><?php print $result['title']; ?> <?php print "Release date: " . $result['release_date'] ?></a>
        </li>
    <?php } ?>
</ul>