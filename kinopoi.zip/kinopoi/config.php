<?php 

    const TMDB_API_KEY_V3 = '913b9c9c4d18b61f66aef356ae680c4a';
    const TMDB_API_URL_V3 = 'https://api.themoviedb.org/3/';
    const TMDB_API_IMG_V3 = 'https://image.tmdb.org/t/p/w300/';

    const TMDB_API_KEY_V4 = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5MTNiOWM5YzRkMThiNjFmNjZhZWYzNTZhZTY4MGM0YSIsInN1YiI6IjVjZmU3OGE5YzNhMzY4MDRhZTIwMjA0MiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.KmSdeNkQm72fAyUlUu66KISL5hgh48T6Rvn4Au70zQo';
    const TMDB_API_URL_V4 = 'https://api.themoviedb.org/4/';
    
?>