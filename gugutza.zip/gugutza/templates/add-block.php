<div>
    <a href="?action=add_heading">+ heading/</a>
    <a href="?action=add_paragraph">+ paragraph/</a>
    <a href="?action=add_image">+ image/</a>
    <a href="?action=remove">REMOVE</a>
</div>