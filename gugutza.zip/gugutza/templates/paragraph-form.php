
<?php 
    return "
        <div>
            <textarea name=\"blocks[]\" cols=\"30\" rows=\"10\" placeholder=\"Heading text...\"></textarea>
        </div>
    ";
?>

<!-- // datorita la blocks salvam datele in aceiasi ordine -->