<?php
    return " 
        <div>
            <input name=\"blocks[][h]\" type=\"text\" placeholder=\"Heading text...\">
        </div>";
?>


