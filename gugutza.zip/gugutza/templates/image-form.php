<?php 
    return "
        <div>
            <input type=\"file\">
        </div>
    ";
?>
    
